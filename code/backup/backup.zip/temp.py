import Citprov
test = Citprov.citprov()
print test.citProv('C00-1068==>P99-1040')
